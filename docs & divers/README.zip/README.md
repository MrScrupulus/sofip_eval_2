# sofip_eval_2
## du 26 MAI au 02 JUIN

## Groupe :
- Yohan @Crack-Boyy
- Valentin @ValentinM-Dev
- Emile @MrScrupulus
- Maxence @MaxenceFeriau01

github [github][1]

github project [projet][4]

figma [figma][2] 

jira [jira][3]

google slides [google][5]

## Branche :
- main
- dev/emile
- dev/yohan
- dev/max
- dev/valentin



## Palette couleur : 
#00FFFF, #111111, #888888, #FF0055, #FFFFFF

## Typographie
 * Titre : Orbitron
 * Texte : Open Sans

## COMPÉTENCE ÉVALUER ##
 - Git/GitHub
 - Veille techno
 - Figma (zoning, wireframes, maquettes, prototypes, repsonsive design).
 - RGPD
 - RGAA
 - Lecture d'un CDC
 - HTML/CSS/JS
 - Gestion de projet
 - README
 - Méthode Agile

## UTILISATION DE L'IA ##
L'utilisation de l'IA est autoriser dans le cadre d'outil d'aide pas pour développer a votre place je resterai vigilent sur le sujet.

## DÉROULER DE L'ÉVALUATION ##
Vous serez composer par équipe de 4, vous aurez chacun un sujet bien défini, des groupes discords seront créer en fonction des équipes vous y aurai accès le jour de l'évaluation.

## L'ÉVALUATION ##
Le 26 mai je vous ouvrirez vos différents salon sur discord, je vous transmettrai le Cahier des charges. Vous aurez jusqu'au 02 Juin inclus pour terminé l'évaluation. Si la demande de délai supplémentaire venant de plusieur groupe est évoquer je rajouterai potentiellement un délai supplémentaire.

## FOAD ##
Pendant votre évalution, vous aurez vos journée de FOAD habituelle, a chaque fin de journée de FOAD individuellement vous me renverrai sur un pdf ou un .md zippé le liens de votre repository GihHub.

[1]: https://github.com/MrScrupulus/sofip_eval_2.git "github"
[2]: https://www.figma.com/design/v6yGZ0EayiDll2E5XLsjvq/Olympe?node-id=0-1&m=dev&t=ErropHid4OW3jxwj-1 "figma"
[3]: https://maxenceferiau.atlassian.net/jira/software/projects/GPO/boards/35 "jira"
[4]: https://github.com/users/MrScrupulus/projects/6 "project"
[5]: https://docs.google.com/presentation/d/17sNL5uXVlgVZGK2xyZBmF8SBIhEyEflxuybh0oX_Bow/edit?usp=sharing "google slides"